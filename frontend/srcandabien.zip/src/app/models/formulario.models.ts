export class Formulario{
    nombre: string;
    cantidad: number;
    precio: number;
    categoria: string;
}