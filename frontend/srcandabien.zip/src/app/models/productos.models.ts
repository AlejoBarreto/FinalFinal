export class Productos{
    id: string;
    nombre: string;
    cantidad: number;
    precio: number;
    categoria: string;
}