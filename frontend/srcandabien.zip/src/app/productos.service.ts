import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs/Observable';
import { Productos } from './models/productos.models';


@Injectable({
  providedIn: 'root'
})
export class ProductosService {

  constructor(private http: HttpClient) { }

  getAll(): Observable<any> {
    return this.http.get('http://localhost:8080/productos')
  }

  deleteProducto(producto){
    return this.http.delete('//localhost:8080/delete' + "/" + producto.id);
  }
}
