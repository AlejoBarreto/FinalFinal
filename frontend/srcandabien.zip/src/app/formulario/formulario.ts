export class Formulario {
    constructor(
    public nombre: string,
    public precio: number,
    public cantidad: number,
    public categoria: string
    ) {}
    }